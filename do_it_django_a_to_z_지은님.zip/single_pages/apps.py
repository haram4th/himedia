from django.apps import AppConfig


class SinglePagesConfig(AppConfig):
    name = 'single_pages'
